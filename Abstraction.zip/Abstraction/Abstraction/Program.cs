﻿using System;

abstract class Parent
{
    public abstract void dad();    //always use abstract keyword
    public void who()
    {
        Console.WriteLine("i am your dad");
    }
}
class Son : Parent
{
    public override void dad()   //always use override keyword
    {
        Console.WriteLine("i am your son bro");
    }
}
class family
{
    static void Main(string[] args)
    {
        Son son = new Son(); //should write some meaning fully object name 
        son.dad();
        son.who();
    }
}
