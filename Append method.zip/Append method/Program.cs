﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Program
    {

        public string name = "Avatar";
        
    }
    public class test
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Storing value dynamically");
            string name1 = "Jack";
            string name2 = "Sully";
            string name3 = $"This is my name {name1} {name2}";//The dolllar helps to store the value dynamically.
            Console.WriteLine(name3);

            Program obj = new Program();
            Console.WriteLine(obj.name);     //calling the string for different class but the access modifer should be public default its private.
            Console.WriteLine('\n');
            Console.WriteLine("Append Method");
            string str = "Avatar";
            string str2 = "Official";
            string str3 = "website";
            StringBuilder sb = new StringBuilder(str);
            sb.Append(str2+str3);
            Console.WriteLine(sb);
            //Console.ReadLine();//Need to give the value as input the ouput box .
            Console.WriteLine('\n');
            Console.WriteLine("Replace Method");
            string Avengers = "Panther is the origin of Avengers";
            string Marvel= Avengers.Replace("Panther", "IronMan");
            Console.WriteLine(Marvel);
          
        }

    }

}


