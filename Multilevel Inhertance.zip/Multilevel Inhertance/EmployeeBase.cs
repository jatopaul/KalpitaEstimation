﻿namespace t1
{
    public class grandpa
    {
       
        public int Age1=100;
            //System.Console.WriteLine(Age1);
           
    }
    public class father:grandpa
    {
        public void digit2()
        {
            int Age2 =40;

        }
    }
    public class Child:father
    {
        public void digit3()
        {
            int Age3 = 10;

        }
    }
}