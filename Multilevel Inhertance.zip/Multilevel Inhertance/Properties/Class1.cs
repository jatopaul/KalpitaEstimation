﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Multilevel_Inhertance.Properties
{
   


    public class grandpa
    {

        //public void Age1(int n,string em) 
        public  void Age1()
        {
            int num = 100;
            Console.WriteLine("Its from gradpa class");
            //Console.WriteLine(n);x`
            //Console.WriteLine(em);


        }


    }
    public class father : grandpa
    {
        public void Age2()
        {
            Console.WriteLine("Its from father class");
        }
    }
    public class Child : father
    {
        public void Age3()
        {
            int num = 100;
            Console.WriteLine("Its from child class");
        }
    }











}
