﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Multilevel_Inhertance.Properties;



public class HelloWorld
{
    public static void Main(string[] args)
    {
        Child child = new Child();
        Console.WriteLine();
        child.Age1();
        child.Age2();
        child.Age3();


    
    }
}
    






