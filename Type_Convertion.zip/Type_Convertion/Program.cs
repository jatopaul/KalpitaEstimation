﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

   class Type_Conversion //by  default for class  internal is the access specifers 
    {
    
    public string charater = "this is a string ";
        public static void Main(string[] args)
        {

        Type_Conversion obj = new Type_Conversion();
        

        //small storge allocation than thesecond datatpe;(implicit)
            byte var = 10;
            int var2 = var;
            Console.WriteLine(var2);

            //explicit type convertion
            double big = 1000.05;
            int small = (int)big;
            Console.WriteLine(small);

            //non-compatable type convertion
            string name1 = "14";
            string name2 = "123456";
            string name3 = "1278";
            


            short number = Convert.ToInt16(name1);
            int number2 = Convert.ToInt32(name2);   //convert class("Convert" is a convert class and "ToInt16" is a method of it
            float number3 = Convert.ToInt64(name3);
            Console.WriteLine(number);
            Console.WriteLine(number2);
            Console.WriteLine(number3);


            string name4 = "1111444";
            //parse 
            int newval = int.Parse(name4);
            Console.WriteLine(newval);
            
            Console.WriteLine("Converting datatype to string");
            
            int newv = 1233;
            string str22 = newv.ToString();//Convert for the int datatype to string datatype
        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine(str22);
        Console.ForegroundColor = ConsoleColor.Black;
    }
    }
  