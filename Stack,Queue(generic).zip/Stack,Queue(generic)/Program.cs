﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stack_generic_
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("List of Stack ");
            Stack<int> numbers = new Stack<int>();//only takes one argument (ike string/int)
            Stack<string> str = new Stack<string>();//only takes one argument (ike string/int)
		    numbers.Push(1);
            numbers.Push(2);
            numbers.Push(3);
            numbers.Push(4);
            str.Push("jato");
            str.Push("paul");
            str.Push("jp");
            str.Push("sasi");


            //numbers.Pop();

            foreach (dynamic item in numbers)// dynamic 
                Console.Write(item + " \n");
            Console.WriteLine("List of queue ");

            Queue<int> callerIds = new Queue<int>();
            callerIds.Enqueue(1);
            callerIds.Enqueue(2);
            callerIds.Enqueue(3);
            callerIds.Enqueue(4);

            foreach (var id in callerIds)
                Console.WriteLine(id);
        }

    }
}
