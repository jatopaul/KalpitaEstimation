﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Collection
{
    public class AbcCmpany
    {
        public int emp_Id { get; set; }
        public string emp_Name { get; set; }
        public string emp_Address { get; set; }
        public string emp_Designation { get; set; }
        public int Age { get; set;}

    }

}



namespace Collection
{
    class EmployeeManagement
    {
        static void Main(string[] args)
        {

            EmployeeManagement obj_Company = new EmployeeManagement();
            List<AbcCmpany> employeeList = new List<AbcCmpany>();
            char ans;
          
            do
            {
                //Console.Clear();
                Console.WriteLine("Employee Details");
                Console.WriteLine("1. Adding an Employee");
                Console.WriteLine("2. Viewing Employee details");
                
                Console.WriteLine("3. Exit\n");
                //Console.WriteLine("----------------------------------------------------------------------------------------");
                Console.Write("Enter the Choice :");
                int choose_number = Convert.ToInt32(Console.ReadLine());

                switch (choose_number)
                {
                    case 1:
                        obj_Company.Function_Add_Employee(employeeList);
                       
                        break;
                    case 2:
                        obj_Company.Function_Display_Employee(employeeList);
                        break;
                    case 3:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalide Choice....Renter!");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                  
                }
                
                Console.Write("Would You Like To Continue(Y/N):");
                ans = Convert.ToChar(Console.ReadLine());
            } while (ans == 'y' || ans == 'Y');
        }


        public void Function_Add_Employee(List<AbcCmpany>employeeList)
        {
            AbcCmpany obj_Comapny1 = new AbcCmpany();
            Console.Write("Enter Employee Id:");
            obj_Comapny1.emp_Id = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Age:");
            obj_Comapny1.Age = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Employee Name:");
            obj_Comapny1.emp_Name = Console.ReadLine();
            Console.Write("Enter Employee Addess:");
            obj_Comapny1.emp_Address = Console.ReadLine();
            Console.Write("Enter Employee Designation:");
            obj_Comapny1.emp_Designation = Console.ReadLine();

            employeeList.Add(obj_Comapny1);
            
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Employee Details Added Successfully...!!!!:");
            Console.ForegroundColor = ConsoleColor.White;



        }

        public void Function_Display_Employee(List<AbcCmpany> employeeList)
        {
            Console.WriteLine("Employee Details");
            Console.WriteLine("------------------------------------------------------------------------------------");
            Console.WriteLine("Employee Id\t Employee Age\tEmployee Name\tEmployee Addess\tEmployee Designation");
            Console.WriteLine("------------------------------------------------------------------------------------");
            foreach (AbcCmpany i in employeeList)
            {
                Console.WriteLine(i.emp_Id + " \t " +i.Age+"\t"+ i.emp_Name + " \t " + i.emp_Address + "   \t " + i.emp_Designation);
            }
            Console.WriteLine("------------------------------------------------------------------------------------");
        }

 
      

    }

}
