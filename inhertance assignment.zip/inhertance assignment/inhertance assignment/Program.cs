﻿using System;
class mobile //base class
{                                   
/// </summary>
    public void MobileType()
    {
        Console.WriteLine("Mobile is Displayless");
    }
}
class Samsung : mobile  //derived  class
{
    public void samsug() {
        Console.WriteLine("Samsung mobile class");
        base.MobileType();//it will take from the base/parent class 
    }
}
class Nokia : mobile  //second derived class
{
    public void nokia()
    {
        Console.WriteLine("Nokia mobile class");
        base.MobileType();
    }
}
class Phones
{
    public static void Main(string[] args)  //main class
    {
        Nokia n = new Nokia();     //creating object
        Samsung  s= new Samsung();
        mobile m = new mobile();
        /*m.MobileType();*/
        n.nokia();
        s.samsug();
        Console.WriteLine();
    }

}