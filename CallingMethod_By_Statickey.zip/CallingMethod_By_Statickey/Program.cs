﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CallingMethod_ByStaticKey
{
    public class Program
    {
        static void Main(string[] args)
        {
            test1.display();
        }
    }
    public static class test1
    {
        public static void display()
        {
            Console.WriteLine("This is a static Data");
        }
    }


}
